/clear @s
/give @s minecraft:dirt 640